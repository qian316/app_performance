#!/bin/sh
# Stop the existing ADB server
# Check the operating system

chmod -R 777 .

# Running on mac
./adb kill-server

./adb nodaemon server -a -P 5037
