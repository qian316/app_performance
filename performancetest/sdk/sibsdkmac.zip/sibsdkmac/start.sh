chmod -R 777 .
./sib_server